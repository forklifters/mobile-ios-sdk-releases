//
//  Appcues.h
//  Appcues
//
//  Created by Yasmin Lindholm on 7/24/18.
//  Copyright © 2018 appcues. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Appcues.
FOUNDATION_EXPORT double AppcuesVersionNumber;

//! Project version string for Appcues.
FOUNDATION_EXPORT const unsigned char AppcuesVersionString[];

// In this header, you should import all the public headers of your framework using statements
// like #import <Appcues/PublicHeader.h>
